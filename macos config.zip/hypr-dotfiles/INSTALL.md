# Hyprland macOS-inspired setup — install & reference guide

Customize before applying: **kb_layout** in `hyprland.conf` (default `us`),
**monitor names** in `conf/monitors.conf` (run `hyprctl monitors` after first
login), your **username's** home path if you edit files as root, and the
**terminal/browser** command aliases at the top of `conf/keybindings.conf`.

## 1. Required packages

| Package | Purpose |
|---|---|
| `hyprland` | The compositor itself |
| `hyprlock` | Lock screen |
| `hypridle` | Idle management (dim/lock/sleep) |
| `xdg-desktop-portal-hyprland` | Screen share, file pickers for sandboxed apps |
| `waybar` | Status bar |
| `rofi-wayland` | App launcher |
| `swaync` | Notification daemon + control center |
| `swww` | Wallpaper daemon (animated transitions) |
| `wl-clipboard` | `wl-copy` / `wl-paste` clipboard tools |
| `cliphist` | Clipboard history, used by Super+C |
| `grim` | Screenshot capture |
| `slurp` | Region selection for screenshots |
| `kitty` | Terminal |
| `zsh` | Shell |
| `thunar` + `thunar-volman` `gvfs` | File manager + trash/mount support |
| `polkit-gnome` | Auth agent (needed for GUI privilege prompts) |
| `brightnessctl` | Backlight control keys |
| `playerctl` | Media key control |
| `pavucontrol` | Audio GUI (used by Waybar click) |
| `wireplumber` `pipewire` `pipewire-pulse` | Audio stack |
| `networkmanager` `network-manager-applet` | Networking + tray icon |
| `bluez` `bluez-utils` `blueman` | Bluetooth + tray icon |
| `ttf-inter` | Inter font (SF Pro-like) |
| `noto-fonts` `noto-fonts-emoji` `ttf-font-awesome` | Fallback glyphs & icons used by Waybar |
| `papirus-icon-theme` | Icon theme |
| `bibata-cursor-theme` (AUR) | macOS-like cursor |
| `qt5ct` `qt6ct` | Qt theming consistency |
| `nwg-look` | GTK theme GUI helper (optional but handy) |

Optional/dock-related:

| Package | Purpose |
|---|---|
| `nwg-dock-hyprland` (AUR) | Dock — see section 2 |

## 2. Installation commands

```bash
# Core (official repos)
sudo pacman -S --needed hyprland hyprlock hypridle xdg-desktop-portal-hyprland \
  waybar rofi-wayland swww wl-clipboard cliphist grim slurp kitty zsh \
  thunar thunar-volman gvfs polkit-gnome brightnessctl playerctl pavucontrol \
  wireplumber pipewire pipewire-pulse networkmanager network-manager-applet \
  bluez bluez-utils blueman ttf-inter noto-fonts noto-fonts-emoji \
  ttf-font-awesome papirus-icon-theme qt5ct qt6ct nwg-look

# swaync is not always in extra; install via AUR if pacman can't find it
yay -S swaync bibata-cursor-theme nwg-dock-hyprland

sudo systemctl enable --now NetworkManager
sudo systemctl enable --now bluetooth
```

If you don't have an AUR helper yet:

```bash
sudo pacman -S --needed base-devel git
git clone https://aur.archlinux.org/yay.git
cd yay && makepkg -si
```

## 3. Directory structure

```
~/.config/hypr/
├── hyprland.conf
├── hyprlock.conf
├── hypridle.conf
└── conf/
    ├── appearance.conf
    ├── animations.conf
    ├── keybindings.conf
    ├── monitors.conf
    ├── autostart.conf
    └── windowrules.conf
~/.config/waybar/
├── config
└── style.css
~/.config/rofi/
└── config.rasi
~/.config/swaync/
├── config.json
└── style.css
```

Copy the provided files into place, then adjust monitor names, keyboard
layout, and wallpaper path (`~/Pictures/Wallpapers/current.jpg`) for your
machine.

## 4. Dock: recommendation

**Use `nwg-dock-hyprland`.** It's purpose-built for Hyprland, reads pinned
apps + running windows via `hyprctl`, auto-hides cleanly, and is far more
stable under Wayland than Plank (which has intermittent Wayland-support
issues) or trying to fake a dock with a second Waybar instance (workable,
but janky auto-hide and double the maintenance surface).

```bash
yay -S nwg-dock-hyprland
```

Minimal launch config (add to `conf/autostart.conf`):

```
exec-once = nwg-dock-hyprland -i 48 -w 6 -mb 10 -x -ex "kitty,thunar,firefox"
```

Flags: `-i` icon size, `-w` icon spacing, `-mb` bottom margin, `-x` auto-hide,
`-ex` pinned launcher entries (comma-separated `.desktop` names or binaries).
Run `nwg-dock-hyprland --help` for the full flag list, since it's actively
developed and options can shift between releases.

**Alternative:** if you want a true always-visible taskbar-with-preview
instead of an auto-hiding dock, a second slim Waybar bar pinned to the
bottom with only `hyprland/taskbar` is workable but needs the
`taskbar` Waybar module, which isn't in every distro build — check
`waybar -v` / your package's compiled features first.

## 5. Wallpaper

```bash
mkdir -p ~/Pictures/Wallpapers
# put an image at ~/Pictures/Wallpapers/current.jpg, or symlink one there
swww-daemon &
swww img ~/Pictures/Wallpapers/current.jpg --transition-type wipe --transition-duration 1.2
```

To change wallpapers on the fly later:

```bash
swww img ~/Pictures/Wallpapers/another.jpg --transition-type grow --transition-pos 0.5,0.5
```

## 6. Applying the configuration

1. Back up any existing configs: `mv ~/.config/hypr ~/.config/hypr.bak` (repeat for waybar/rofi/swaync).
2. Copy the new files into place, matching the directory structure above.
3. From a TTY (Ctrl+Alt+F3) or your display manager, start a Hyprland session.
4. If it fails to start, check logs (section 7) before assuming the config is broken — missing packages are the most common cause.
5. If you're mid-session and want to reload without logging out: `hyprctl reload`.

**Recovery if Hyprland won't start:** drop to a TTY, run
`Hyprland` directly to see the error inline, or check `~/.local/share/hyprland/hyprland*.log`.
Comment out the newest block you added in `hyprland.conf` (or temporarily
`mv` your config aside) to isolate the offending line, then re-enable
piece by piece.

## 7. Troubleshooting

```bash
# Hyprland's own log (most recent session)
cat $(ls -t ~/.local/share/hyprland/hyprland*.log | head -1)

# List monitors and their exact names/modes
hyprctl monitors

# Waybar errors (run in foreground from a terminal inside Hyprland)
killall waybar; waybar -l trace

# Check what's bound to a key (look for duplicate binds)
hyprctl binds

# Restart just SwayNC
killall swaync; swaync &

# Restart just Waybar
killall waybar; waybar &

# Reload Hyprland config without restarting the session
hyprctl reload

# General Hyprland health/config dump
hyprctl systeminfo
```

## 8. Customization quick-reference

| Change | Where |
|---|---|
| Accent color | `col.active_border` in `appearance.conf`, `@accent`/`#8aa3ff` in `rofi/config.rasi`, `#8aa3ff` in `waybar/style.css` |
| Wallpaper | `swww img <path>` (section 5), and update the path in `autostart.conf` + `hyprlock.conf`'s `background.path` |
| Font | Replace `Inter` in `waybar/style.css`, `rofi/config.rasi`, and `hyprlock.conf` labels |
| Bar position | `"position": "top"` → `"bottom"` in `waybar/config` |
| Gaps | `gaps_in` / `gaps_out` in `hyprland.conf`'s `general {}` block |
| Animation speed | Second numeric field in each `animation =` line in `animations.conf` (lower = faster) |
| Keyboard layout | `kb_layout` in `hyprland.conf`'s `input {}` block |
| Monitor resolution | `conf/monitors.conf` — edit the active `monitor =` line |

## 9. Accessibility & usability notes

- Increase `font_size` values in Waybar/Rofi CSS if text is too small.
- `kb_options = caps:escape` in `hyprland.conf` remaps Caps Lock — delete that line if you rely on Caps Lock normally.
- For larger click targets, bump `element { padding }` in `rofi/config.rasi`.
- If motion sensitivity is a concern, set `animations { enabled = false }` in `animations.conf` rather than deleting the file (keeps the bezier definitions harmless but inert).
- `hypridle.conf`'s dim/lock/suspend timeouts can be lengthened for users who need more time before the screen changes state.

## 10. Final verification checklist

- [ ] `hyprctl monitors` shows the names you used in `monitors.conf`
- [ ] Super+Space opens Rofi; Super+Return opens kitty
- [ ] Super+Q and Super+W both close the focused window
- [ ] Super+1–9 switches workspaces; Super+Shift+1–9 moves windows
- [ ] Super+H/J/K/L moves focus; Super+Shift+H/J/K/L moves windows
- [ ] Super+F fullscreens; Super+V toggles floating
- [ ] Print Screen triggers a region screenshot via `grim`+`slurp`
- [ ] Waybar shows workspaces, clock, network, audio, battery, bluetooth, tray
- [ ] SwayNC opens with Super+N and shows rounded, blurred panels
- [ ] `swww` wallpaper is set and persists after `hyprctl reload`
- [ ] hyprlock triggers on Super+Ctrl+L and matches the dark theme
- [ ] hypridle dims/locks/sleeps on the timers you're comfortable with
- [ ] Touchpad: natural scroll, tap-to-click, and disable-while-typing all behave as expected
- [ ] Dock (`nwg-dock-hyprland`) shows pinned + running apps and auto-hides

## Version caveat

Hyprland's config syntax has changed across releases (e.g. `windowrulev2`
was merged into `windowrule`, `decoration { blur { } }` nesting, `bezier`
animation curve names). Everything here targets a modern Hyprland (0.40+).
Run `hyprctl version` — if you're on something older, check the
[Hyprland wiki changelog](https://wiki.hyprland.org) for the equivalent
syntax of any option that fails to parse on `hyprctl reload`.
